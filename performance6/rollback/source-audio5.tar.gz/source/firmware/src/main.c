/* SPDX-License-Identifier: GPL-3.0-only
 * Copyright (C) 2026 Kerem Kilic (Ellic Studio)
 * Portions Copyright (C) 2026 Leo Kuroshita (@kurogedelic), Hügelton Instruments */
/* MELODEE boot and main loop. Boot order: WDT first, boot-loop guard, fatal vectors,
 * guards; then LCD, input (TIMER5 IRQ, 10 kHz), audio (ALNK0 IRQ). */
extern uint32_t _data_start[], _data_end[], _data_load[], _bss_start[], _bss_end[];
extern uint32_t _dsp_start[], _dsp_end[], _dsp_load[], _dt_start[], _dt_end[], _dt_load[];
extern uint32_t _audio_start[], _audio_end[], _audio_load[];
extern uint32_t _pool_start[], _pool_end[], _rt_start[], _rt_end[], _rt_load[];


/* TIMER5 outranks ALNK0, so the scan keeps its 100 us pace while a half buffer renders: before,
 * the ticks stopped for the whole render (0.7 ms idle, several ms loaded), the column lit when it
 * began stayed lit that long (a ~16 Hz flicker over all LEDs, beating with the scan) and the
 * encoders lost frames. Nested in ALNK0 it scans GPIO, counts ms and receives TRS MIDI;
 * USB MIDI polls wait for the first tick after the render,
 * while UART input keeps polling into its single-producer MIDI queue,
 * and the time spent nested is handed to the audio ISR so its load figures stay render-only.
 * The USB audio streams cannot wait for the render (a packet each way per 1 ms frame, a render takes up to
 * ~5 ms): ua_service also runs nested, by elapsed time (every 250 us at most: work spanning ticks does not
 * stretch the next deadline). It touches only the audio endpoints (INDEX is set on every access) and the
 * USB side of the audio rings (audio.c copies with the IRQs off), and usb_poll never runs nested, so the
 * two never interleave. */
void fm1_timer5_irq(void)
{
    static uint32_t sub, owed;
    uint32_t t0 = fm1_ticks(), usb_due = sub % 5u == 0u;
    fm1_timer5_ack();
    melodee_dbg.timer_irqs++;
    AP_START(input_start);fm1_input_tick();
    if(melodee_dbg.in_audio){AP_END(AP_INPUT,input_start);}
    {   /* milliseconds from the 24 MHz TIMER4 (robust to a late tick) */
        static uint32_t last, acc;
        acc += t0 - last;
        last = t0;
        while (acc >= 1000u * FM1_TICKS_PER_US) {
            acc -= 1000u * FM1_TICKS_PER_US;
            fm1_ms++;
        }
    }
    if (usb_due)
        owed |= 1u;                             /* 2 kHz: all USB SIE traffic lives here */
#if MELODEE_UART
    if (sub % 5u == 2u)
        owed |= 2u;                             /* 2 kHz: <= ~7 bytes per call at 31250 baud */
#endif
    if (++sub == 10u)
        sub = 0;
#if MELODEE_USB_AUDIO
    {
        static uint32_t last_ua;
        uint32_t gap = t0 - last_ua;
        if (!last_ua || gap >= 250u * FM1_TICKS_PER_US) {
            if (last_ua && gap > ua.poll_max_ticks)
                ua.poll_max_ticks = gap;
            last_ua = t0;
            AP_START(usb_start);ua_service();
            if(melodee_dbg.in_audio){AP_END(AP_USB,usb_start);}                       /* at most 4 kHz, independent of coalesced ticks */
            gap = fm1_ticks() - t0;
            if (gap > ua.service_max_ticks)
                ua.service_max_ticks = gap;
        }
    }
#endif
    /* TRS RX only touches its DMA ring and publishes timestamped input. It
     * can safely nest in audio; deferring it made clock jitter depend on load. */
#if MELODEE_UART
    if (owed & 2u) {
        AP_START(midi_start);uart_midi_poll();
        if(melodee_dbg.in_audio){AP_END(AP_MIDI_RX,midi_start);}
        owed &= ~2u;
    }
#endif
    if (melodee_dbg.in_audio) {
        melodee_dbg.nested++;
        uint32_t elapsed=fm1_ticks()-t0;t5_nested_ticks+=elapsed;
        if(elapsed>audio_timer5_max_ticks)audio_timer5_max_ticks=elapsed;
#if MELODEE_AUDIO_PROFILE
        audio_profile_add(AP_TIMER5,elapsed);
#endif
        return;
    }
    if (owed & 1u)
        usb_poll();
    owed = 0;
    /* The ISR footer can be preempted after the C audio-active flag clears.
     * Its conservative bound therefore needs ordinary TIMER5 service too. */
    uint32_t elapsed=fm1_ticks()-t0;
    if(elapsed>audio_timer5_max_ticks)audio_timer5_max_ticks=elapsed;
}
extern void isr_timer5(void);

static void timer5_start(void)                 /* OSC /4 = 6 MHz, PRD 600 -> 10 kHz */
{
    fm1_timer5_start(isr_timer5, 4);   /* above ALNK0 (3): the scan nests into the render (see fm1_timer5_irq) */
}

/* The voices CPU1 + CPU0 carry at the clock running: the SPL's 360 MHz, or a 320 that a soft reset kept from a
 * 1.3.x / 1.4 rc session until power-off (hal/fm1_clock.h: Melodee never writes the PLL) */
static void clock_boot(void)
{
    uint32_t m = fm1_clock_mult();
    vbudget_cpu1 = VBUDGET * (m ? fm1_clock_mhz_of(m) : 360u) / 360u;
}

static void hexs(char *b, uint32_t v)
{
    uint32_t i;
    for (i = 0; i < 8u; i++)
        b[i] = "0123456789ABCDEF"[(v >> (28u - 4u * i)) & 15u];
    b[8] = 0;
}

static void fm1_fault(const fm1_crash_t *c)
{
    char b[12];
    uint32_t t0;
#if MELODEE_DUAL_CORE
    if (audio_worker_online)
        fm1_core1_bar_set();                          /* one core on every boot until power-off */
#endif
    fm1_audio_stop();
    scr_wake_now();
    lcd_fill(0, 0, 240, 240, UI_CRASH_BG);            /* fixed, outside the palettes */
    draw_text_line(0, 10, 240, TY_TX, "Melodee crash", UI_CRASH_INK, UI_CRASH_BG, 1);   /* (large type) */
    hexs(b, c->vec);
    draw_text_line(10, 48, 220, TY_TX, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->pc);
    draw_text_line(10, 76, 220, TY_TX, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->emu);
    draw_text_line(10, 112, 220, TY_TX, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->dbg);
    draw_text_line(10, 140, 220, TY_TX, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    hexs(b, c->rets);
    draw_text_line(10, 168, 220, TY_TX, b, UI_CRASH_INK, UI_CRASH_BG, 0);
    t0 = fm1_ticks();
    while ((uint32_t)(fm1_ticks() - t0) < 4000u * 1000u * FM1_TICKS_PER_US)
        ;
    fm1_reboot();
}

/* power-on: the parts with their default sounds (TRK_DEF); the sequencers empty */
static void melodee_init(void)
{
    uint32_t i;
    chain_defaults(&chain_config);
    pattern_init();
    for (i = 0; i < G_COUNT; i++)
        song.g[i] = GP[i].def;
    undo_depth++;                             /* (no undo copy of the power-on loads) */
    fm6_init();                               /* every track's FM6 patch: the init voice */
    cz_init();
    for (i = 0; i < NTRK; i++) {
        track_t *t = &trk[i];
        track_defaults(t);
        set_engine_of(t, TRK_DEF[i][0]);
        apply_preset_to(t, TRK_DEF[i][1]);    /* with its sends */
        t->engine = t->eng_req;
        track_defaults_steps(t);              /* (a sound load never touches them) */
        pat_sig[i] = steps_sig(t);            /* (empty: not the user's) */
        pat_last[i] = 0;
    }
    undo_depth--;
    song.sel = 0;
    song.master_q12 = 2048;
    ui.home = 1;
    ui.force = 1;
}

static void fm1_main(void)
{
    int32_t knob = 512 * 16;
    fm1__pc_out(6,0);                         /* codec held quiet before flash and splash */
    settings_init();                           /* a readable default palette before loading flash */
    lcd_init();                                /* maintenance must be visible before any boot writes */
    lcd_fill(0, 0, 240, 240, T_BG);
    draw_text_box(0, 70, 240, TY_HR, "MELODEE", T_THEME, 1);   /* (large type) */
    draw_text_box(0, 140, 240, TY_TX, "Starting up", T_MID, 1);
    lcd_sync();
    dsp_tables_init();                        /* the RAM lookup tables (FM6), before anything renders */
    persist_boot();
#if MELODEE_OTA
    if (flash_ok && boot_work.state != 2u)
        ota_boot_cleanup();                             /* staging area left by an update */
#endif
    settings_init();
    clock_boot();                             /* the voice budget at the clock found (never changed) */
    if (boot_work.state != 2u) {
        lcd_fill(0, 0, 240, 240, T_BG);
        draw_text_box(0, 70, 240, TY_HR, "MELODEE", T_THEME, 1);
        draw_text_box(0, 140, 240, TY_TX, "Multi-engine synth", T_MID, 1);
    }
    if (melodee_dbg.magic != DBG_MAGIC) {
        memset(&melodee_dbg, 0, sizeof melodee_dbg);
        melodee_dbg.magic = DBG_MAGIC;
    }
    melodee_dbg.boots++;
    melodee_dbg.max_us = 0;
    melodee_dbg.in_audio = 0;                       /* .noinit: a reset inside the audio ISR left it set, and
                                                       TIMER5 would treat every tick as nested (no USB poll) */
    melodee_dbg.prev_stage = melodee_dbg.stage;     /* a WDT reset leaves the last breadcrumb here */
    melodee_dbg.prev_page = melodee_dbg.page;
    melodee_dbg.prev_home = melodee_dbg.home;
    melodee_dbg.prev_frames = melodee_dbg.ui_frames;
    melodee_dbg.prev_rst = fm1_boot.p3_rst;
    fm1_input_init();
    fm1_adc_init();
    panel_init();
    melodee_init();
#if MELODEE_DUAL_CORE
    /* One core if stock supply setup failed, after a crash in the first 30 s (a second would enter UBOOT),
     * and until power-off once CPU1 was retired or CPU0 crashed beside it. */
    if (fm1_power_ready && !bootguard.failed && !fm1_core1_barred())
        fm1_multicore_start();              /* bounded handshake; failure keeps serial rendering */
    /* CPU1 starts through mask-ROM before it reaches our RAM worker. Restrict
     * instruction fetch only after that bootstrap has returned, or stopped
     * the core on timeout. The captured first-device fault was DBG bit 10
     * (c1_pc_limit_err_r) while CPU0 waited for the ready handshake. */
    fm1_guard_enable(FM1_GUARD_PC);
#endif
    audio_init();
    usb_start();
#if MELODEE_UART
    uart_midi_init();
#endif
    timer5_start();
    fm1_guard_lock_top();
    fm1_irq_enable_all();
    fm1_delay_ms(30);
    if ((fm1_in.buttons & 3u) == 3u) {
        panel_setup();                        /* OCT- + OCT+ held at power-on */
        settings_save();
    }
    glo_restore();                            /* CLK TUNE MIDI ROUT as last used, */
    project_boot();                           /* then the BOOT project or the template (theirs win) */
    fm1_delay_ms(400);
    if (boot_work.state != 2u)
        lcd_fill(0, 0, 240, 240, T_BG);

    for (;;) {
        uint32_t m = fm1_ms;
        fm1_wdt_feed();
        usb_retry(fm1_ms);
#if MELODEE_USB_AUDIO
        if (ua_off_apply(fm1_ms)) {                     /* USB direction or capture mode changed: the host re-reads */
            settings_save();                            /* while off the bus: no USB deadline missed */
            ui_say("USB ", "RECONNECTING");
        }
#endif
        if (fm1_ms > 30000u && bootguard.pending) {     /* a crash or hang in the first 30 s counts */
            bootguard.pending = 0;
            bootguard.failed = 0;
        }
        {
            int32_t b = fm1_adc_read(FM1_ADC_BATT);     /* battery: slow IIR */
            if (b > 0)
                song.batt_raw = song.batt_raw ? song.batt_raw + (b - song.batt_raw) / 32 : b;
        }
        {
            int32_t a = fm1_adc_read(FM1_ADC_MASTER);
            if (a >= 0) {
                uint32_t k10;
                knob += (a * 16 - knob) / 8;
                k10 = (uint32_t)(knob / 16);
                song.master_q12 = (k10 * k10) >> 8;            /* 0 .. ~4096 */
            }
        }
        {   /* OCT- + OCT+ held 5 s: enter UBOOT with RAM intact (debug / update); a countdown
             * shows from 2 s over the whole screen (the menu and the dialogs too: ui_draw), letting
             * go cancels it */
            static uint32_t t0;
            uint32_t both = (1u << panel.btn[B_OCTDN]) | (1u << panel.btn[B_OCTUP]);
            if ((fm1_in.buttons & both) != both) {
                if (ui.uboot) {
                    ui.uboot = 0;
                    ui.force = 1;                       /* what the countdown covered */
                    ui_message("UPDATE CANCELLED");
                }
                t0 = fm1_ms;
            } else if (fm1_ms - t0 > 2000u && fm1_ms - t0 <= 5000u) {
                uint32_t left = (5000u - (fm1_ms - t0) + 999u) / 1000u;
                if (left != ui.uboot) {
                    ui.uboot = (uint8_t)left;
                    ui.force = 1;
                }
            } else if (fm1_ms - t0 > 5000u) {
                fm1_audio_stop();
                scr_wake_now();
                lcd_fill(0, 0, 240, 240, T_BG);
                draw_text_box(0, 100, 240, TY_VL, "UBOOT", T_THEME, 1);
                usb_detach();
                fm1_delay_ms(30);
                reset_intended();
                fm1_enter_uboot();
            }
        }
        cz_service();
        fm6_service();                                  /* DX7 SysEx for FM6, a pending FM6 settings save */
#if MELODEE_OTA
        ed_service();                                   /* web editor SysEx */
        ota_service();                                  /* M-UPGRADE handshake */
        if (usb.ota_req) {                              /* M-UPGRADE upgrade command */
            usb.ota_req = 0;
            panic_req = (1u << NTRK) - 1u;               /* every track (bit per track) */
            if (flash_ok)
                ota_session();                          /* returns only if nothing was committed */
            lcd_fill(0, 0, 240, 240, T_BG);
            ui.force = 1;
        }
#endif
        if (usb.uboot_req) {                            /* SysEx F0 22 24 35 7D F7 from the host */
            fm1_audio_stop();
            lcd_fill(0, 0, 240, 240, T_BG);
            draw_text_box(0, 100, 240, TY_VL, "UBOOT (USB)", T_THEME, 1);
            fm1_delay_ms(20);
            usb_detach();
            fm1_delay_ms(30);
            reset_intended();
            fm1_enter_uboot();
        }
#if MELODEE_CDC
        cdc_task();
#endif
        melodee_dbg.ui_frames++;
        melodee_dbg.page = ui.page;
        melodee_dbg.home = ui.home;
        melodee_dbg.stage = 1;
        ui_input();
        glo_poll();                                     /* a kept GLO value changed: the settings, later */
        settings_poll();                              /* queued settings save: only while stopped */
        melodee_dbg.stage = 2;
        ui_leds();
        ui_draw();
        melodee_dbg.stage = 9;
        while (fm1_ms - m < 15u) {                               /* ~60 UI frames/s at most */
            ui_input();
#if MELODEE_OTA
            ed_service();                       /* editor replies without waiting for the next frame */
#endif
        }
    }
}

void fm1_cstart(void)
{
    uint32_t *s, *d, p3, src, wdt;
    fm1_time_init();
    fm1_reset_reason();
    p3 = fm1_boot.p3_rst;
    src = fm1_boot.rst_src;
    wdt = fm1_boot.wdt_con;
    fm1_wdt_arm(0x0D);
    fm1_core1_stop();                      /* hold CPU1 before clearing/copying application RAM */
    if (bootguard.magic != BOOTGUARD_MAGIC) {
        bootguard.magic = BOOTGUARD_MAGIC;
        bootguard.failed = 0;
        bootguard.pending = 0;
    }
    if (bootguard.pending)
        bootguard.failed++;
    bootguard.pending = 1;
    if (bootguard.failed >= 2u) {
        bootguard.failed = 0;
        bootguard.pending = 0;
        fm1_enter_uboot();
    }
    fm1_irq_init();
    for (d = _bss_start; d < _bss_end; d++)
        *d = 0;
    for (d = _pool_start; d < _pool_end; d++)
        *d = 0;
    for (s = _data_load, d = _data_start; d < _data_end; s++, d++)
        *d = *s;
    for (s = _rt_load, d = _rt_start; d < _rt_end; s++, d++)
        *d = *s;                                /* flash driver code that must run from RAM */
    for (s = _dsp_load, d = _dsp_start; d < _dsp_end; s++, d++)
        *d = *s;                                /* DSP code: audio is stopped while NOR is busy */
    for (s = _dt_load, d = _dt_start; d < _dt_end; s++, d++)
        *d = *s;                                /* the oscillator correction tables */
    for (s = _audio_load, d = _audio_start; d < _audio_end; s++, d++)
        *d = *s;                                /* resident audio profile: executable ordinary SRAM */
    fm1_mailbox_clear();
    fm1_power_ready = (uint8_t)fm1_power_init(); /* stock V15 supplies before cache, peripherals or CPU1 */
#if MELODEE_CACHE_RAM
    {   /* XIP-to-SRAM exceeds the direct-call range on pi32v2. */
        void (*volatile init)(uint32_t) = fm1_cache_init;
        init(bootguard.failed);             /* copied RAM code; IRQs off, CPU1 held */
    }
#endif
    fm1_guard_enable(FM1_GUARD_STACK | FM1_GUARD_WRITE | FM1_GUARD_BUS
#if !MELODEE_DUAL_CORE
                     | FM1_GUARD_PC
#endif
                     );
    fm1_boot.p3_rst = (uint8_t)p3;
    fm1_boot.rst_src = src;
    fm1_boot.wdt_con = (uint8_t)wdt;
    fm1_main();
    for (;;)
        ;
}
